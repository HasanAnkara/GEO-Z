# GEOİZ 1.0.0 — APK Hazır Proje

**Slogan:** Dünyayı anlamanın yolu.

Bu paket GEOİZ'in Supabase bağlantılı web uygulamasını Android WebView uygulamasına dönüştürmek için hazırlanmıştır.

## İçerik
- `app/src/main/assets/index.html` — GEOİZ uygulaması
- `app/src/main/` — Android uygulama kabuğu
- `.github/workflows/build-apk.yml` — GitHub Actions ile otomatik APK derleme
- `settings.gradle`, `build.gradle` — Android Gradle projesi

## APK üretimi
GitHub Actions, `main` dalına her push işleminden sonra otomatik olarak `app-debug.apk` üretir. Ayrıca GitHub'da **Actions → Build GEOIZ APK → Run workflow** ile elle de başlatılabilir.

Derlenen APK, workflow'un **Artifacts** bölümünde `GEOIZ-1.0.0-debug-apk` adıyla bulunur.

## Teknik not
Uygulama Android Studio veya yerel Android SDK gerektirmeden GitHub'ın bulut derleme ortamında derlenmek üzere hazırlanmıştır.
