GEOİZ 1.0 — APK'YA HAZIR ANDROID PROJESİ
==========================================

Uygulama adı: GEOİZ
Slogan: Dünyayı anlamanın yolu.
Application ID: com.geoiz.app
Version: 1.0 (versionCode 1)

BU PAKET NE İÇERİYOR?
---------------------
- Android WebView uygulaması
- GEOİZ 1.0 web arayüzü assets/index.html içinde
- Supabase bağlantısı
- Harita/Leaflet desteği
- Ana Android manifesti ve kaynakları

DERLEME GEREKSİNİMLERİ
----------------------
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- JDK: 17
- compileSdk: 35
- targetSdk: 35
- minSdk: 23

Android Gradle Plugin 8.6.x için JDK 17 ve Gradle 8.7 gereklidir.

APK ÜRETME
----------
Android Studio ile proje klasörü olan GEOIZ-1.0-APK-READY açılır.
Gradle senkronizasyonundan sonra:
Build > Generate App Bundles or APKs > Generate APKs

Oluşan debug APK genellikle:
app/build/outputs/apk/debug/app-debug.apk

NOT
---
Bu sohbet ortamında Android SDK/Gradle derleme zinciri bulunmadığı için
APK dosyası burada derlenmiş olarak sunulmamaktadır. Bu paket APK derlemesine
hazır proje olarak hazırlanmıştır.

GEOİZ web içeriği internet bağlantısı üzerinden Leaflet ve Supabase servislerini
kullanır; uygulamanın canlı veri ve harita özellikleri için internet bağlantısı
gerekir.
