# GEOİZ 1.0.0

- Öğrenci ana ekranı ve günlük öğrenme rotası
- Konu, harita, test ve analiz akışı
- Yanlışlar ve tekrar alanı
- Öğrenme önerileri
- Öğretmen paneli
- Supabase veri bağlantısı
- Android WebView kabuğu
- GitHub Actions otomatik APK derlemesi
- Android tema bağımlılığı sadeleştirildi; AppCompat gerektirmiyor
