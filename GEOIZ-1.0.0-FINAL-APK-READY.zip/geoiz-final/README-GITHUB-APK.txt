GEOIZ 1.0 — APK BUILD GUIDE

Bu proje GitHub Actions ile bulutta debug APK üretmeye hazırdır.

1) GitHub'da yeni bir repository oluşturun.
2) Bu ZIP'in içindeki tüm dosya ve klasörleri repository'nin köküne yükleyin.
3) GitHub'da Actions sekmesini açın.
4) "Build GEOIZ APK" workflow'unu seçin.
5) "Run workflow" ile manuel derlemeyi başlatın.
6) İşlem tamamlandığında ilgili workflow çalışmasının Artifacts bölümünden
   GEOIZ-1.0-debug-apk paketini indirin.

Not: Bu bir debug APK'dır; test amaçlı doğrudan cihaza kurulabilir.
Play Store yayını için ayrıca release imzalama ve mağaza hazırlığı gerekir.
